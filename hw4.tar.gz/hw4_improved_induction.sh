#!/bin/sh
python3 pcfg_create_improved.py $1 > $2