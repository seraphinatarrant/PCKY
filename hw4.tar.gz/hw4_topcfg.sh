#!/bin/sh
python3 pcfg_create.py $1 > $2