#!/bin/sh
python3 example_cky.py $1 $2 $3